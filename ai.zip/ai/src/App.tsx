import { useState } from 'react';
import FloatingElements from './components/FloatingElements';
import SparklesBackground from './components/SparklesBackground';
import EntryGate from './components/EntryGate';
import CaptchaSection from './components/CaptchaSection';
import MusicController from './components/MusicController';
import WelcomeSection from './components/WelcomeSection';
import CakeSection from './components/CakeSection';
import MetricsSection from './components/MetricsSection';
import ReasonsAccordion from './components/ReasonsAccordion';
import GallerySection from './components/GallerySection';
import LetterSection from './components/LetterSection';
import Footer from './components/Footer';
import ScrollToTop from './components/ScrollToTop';

type Stage = 'gate' | 'captcha' | 'main';

function App() {
  const [stage, setStage] = useState<Stage>('gate');

  // Stage 1 → 2: User clicked "Yes, let me see my greatness"
  const handleEnterGate = () => {
    setStage('captcha');
    // Try to start the music
    setTimeout(() => {
      const audio = document.querySelector('audio');
      if (audio) {
        audio.play().catch(() => {
          // Autoplay blocked - that's okay, user can use the music widget
        });
      }
    }, 300);
  };

  // Stage 2 → 3: User passed captcha
  const handleCaptchaVerified = () => {
    setStage('main');
    // Scroll to the cake section after a brief delay
    setTimeout(() => {
      const cakeSection = document.getElementById('cake');
      if (cakeSection) {
        cakeSection.scrollIntoView({ behavior: 'smooth' });
      }
    }, 300);
  };

  return (
    <>
      {/* STAGE 1: Entry Gate */}
      {stage === 'gate' && <EntryGate onEnter={handleEnterGate} />}

      {/* STAGE 2: Captcha */}
      {stage === 'captcha' && <CaptchaSection onVerified={handleCaptchaVerified} />}

      {/* STAGE 3: Main site (always rendered, hidden behind overlays) */}
      <div className={`relative min-h-screen bg-cream overflow-x-hidden transition-opacity duration-700 ${stage === 'main' ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
        <FloatingElements />
        <SparklesBackground />

        {/* Persistent floating music widget */}
        <MusicController />

        <main className="relative z-10">
          <WelcomeSection />
          <CakeSection />
          <MetricsSection onSubmit={() => {
            const reasonsSection = document.getElementById('reasons');
            if (reasonsSection) reasonsSection.scrollIntoView({ behavior: 'smooth' });
          }} />
          <GallerySection />
          <ReasonsAccordion />
          <LetterSection />
          <Footer />
        </main>

        <ScrollToTop />
      </div>
    </>
  );
}

export default App;
