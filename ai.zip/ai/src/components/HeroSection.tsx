import { useState, useEffect, useCallback } from 'react';
import { Music, VolumeX, ChevronDown } from 'lucide-react';
import { motion } from 'framer-motion';

// ============================================
// CUSTOMIZE: Set her birthday date here!
// Format: YYYY-MM-DDTHH:MM:SS
// ============================================
const BIRTHDAY_DATE = '2026-06-24T00:00:00';

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export default function HeroSection() {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);

  const calculateTimeLeft = useCallback(() => {
    const now = new Date().getTime();
    const birthday = new Date(BIRTHDAY_DATE).getTime();
    const difference = birthday - now;

    if (difference > 0) {
      return {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / (1000 * 60)) % 60),
        seconds: Math.floor((difference / 1000) % 60),
      };
    }
    // If birthday has passed, count up from birthday
    const elapsed = Math.abs(difference);
    return {
      days: Math.floor(elapsed / (1000 * 60 * 60 * 24)),
      hours: Math.floor((elapsed / (1000 * 60 * 60)) % 24),
      minutes: Math.floor((elapsed / (1000 * 60)) % 60),
      seconds: Math.floor((elapsed / 1000) % 60),
    };
  }, []);

  useEffect(() => {
    setTimeLeft(calculateTimeLeft());
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);
    return () => clearInterval(timer);
  }, [calculateTimeLeft]);

  const toggleMusic = () => {
    setIsMusicPlaying(!isMusicPlaying);
    setHasStarted(true);
    // Note: In a real implementation, you'd add an <audio> element
    // and play/pause it here. For now, we just toggle the visual state.
  };

  const TimeBox = ({ value, label }: { value: number; label: string }) => (
    <div className="flex flex-col items-center mx-2 sm:mx-4">
      <div className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 rounded-2xl glass flex items-center justify-center animate-pulse-glow">
        <span className="text-2xl sm:text-3xl md:text-4xl font-bold font-playfair text-rose-gold">
          {String(value).padStart(2, '0')}
        </span>
      </div>
      <span className="mt-2 text-xs sm:text-sm font-lato text-rose-gold/80 uppercase tracking-widest">{label}</span>
    </div>
  );

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden px-4">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-pink-50 via-cream to-lavender -z-10" />
      
      {/* Decorative circles */}
      <div className="absolute top-20 left-10 w-64 h-64 rounded-full bg-pink-100/40 blur-3xl -z-10" />
      <div className="absolute bottom-20 right-10 w-80 h-80 rounded-full bg-lavender/40 blur-3xl -z-10" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full bg-cream-dark/30 blur-3xl -z-10" />

      {/* Music toggle */}
      <motion.button
        initial={{ opacity: 0, scale: 0 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 1.5, type: 'spring' }}
        onClick={toggleMusic}
        className={`absolute top-6 right-6 z-50 w-12 h-12 rounded-full glass flex items-center justify-center transition-all duration-300 hover:scale-110 ${
          isMusicPlaying ? 'music-pulse' : ''
        }`}
        title="Toggle background music"
      >
        {isMusicPlaying ? (
          <Music size={20} className="text-rose-gold" />
        ) : (
          <VolumeX size={20} className="text-rose-gold/60" />
        )}
      </motion.button>

      {/* Main content */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, ease: 'easeOut' }}
        className="text-center z-10"
      >
        {/* Small greeting */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-rose-gold font-dancing text-xl sm:text-2xl md:text-3xl mb-4"
        >
          To the most amazing person I know...
        </motion.p>

        {/* Main heading */}
        <motion.h1
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5, duration: 0.8, type: 'spring' }}
          className="font-playfair text-4xl sm:text-5xl md:text-7xl lg:text-8xl font-bold gradient-text leading-tight mb-2"
        >
          Happy Birthday
        </motion.h1>

        <motion.h2
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.7, duration: 0.8, type: 'spring' }}
          className="font-dancing text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-rose-gold mb-8"
        >
          to My Ultimate Favorite Human!
        </motion.h2>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9 }}
          className="text-rose-gold/70 font-lato text-sm sm:text-base md:text-lg max-w-xl mx-auto mb-10 px-4"
        >
          This day is all about celebrating YOU — the laughter, the memories, 
          and every beautiful moment we've shared.
        </motion.p>

        {/* Countdown Timer */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.1, duration: 0.8 }}
          className="flex flex-wrap justify-center items-center mb-12"
        >
          <TimeBox value={timeLeft.days} label="Days" />
          <TimeBox value={timeLeft.hours} label="Hours" />
          <TimeBox value={timeLeft.minutes} label="Mins" />
          <TimeBox value={timeLeft.seconds} label="Secs" />
        </motion.div>

        {/* CTA Button */}
        <motion.a
          href="#gallery"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.3 }}
          className="inline-block px-8 py-4 bg-gradient-to-r from-rose-gold to-rose-gold-light text-white font-lato font-semibold rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 animate-pulse-glow"
        >
          Explore Your Special Day ✨
        </motion.a>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <a href="#gallery" className="flex flex-col items-center text-rose-gold/60 hover:text-rose-gold transition-colors">
          <span className="text-xs uppercase tracking-widest mb-2">Scroll</span>
          <ChevronDown size={24} className="animate-bounce" />
        </a>
      </motion.div>

      {/* Music note hint */}
      {hasStarted && isMusicPlaying && (
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute bottom-20 left-1/2 -translate-x-1/2 text-xs text-rose-gold/50"
        >
          🎵 Music is playing... (Add your audio file in the code!)
        </motion.p>
      )}
    </section>
  );
}
