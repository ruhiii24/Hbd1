import { useState } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { useRef } from 'react';
import { ChevronDown, Gavel, FileText } from 'lucide-react';

// ============================================
// CUSTOMIZE: Edit these reasons to make them personal!
// Each reason has a roast header and a sweet/funny explanation.
// ============================================
const REASONS = [
  {
    id: 1,
    header: 'Reason #1: You know too many of my secrets to be left alive',
    explanation:
      'Honestly, you are a security liability. You have blackmail material on me that could end careers. I HAVE to keep you around. It is purely self-preservation. (Okay fine, also love. Mostly self-preservation though.)',
  },
  {
    id: 2,
    header: 'Reason #2: Your laugh makes me look normal',
    explanation:
      'Without your unhinged cackle in public places, people would just stare at ME weirdly. You take the heat. You are my chaos shield. Thank you for your service.',
  },
  {
    id: 3,
    header: 'Reason #3: Excellent taste in best friends (me)',
    explanation:
      'Out of all the billions of people on this planet, you chose ME. That is either the best decision you ever made or the worst, but either way, I am honored and will be putting this on my resume.',
  },
  {
    id: 4,
    header: 'Reason #4: You are legally bound to me (we signed a contract in 4th grade)',
    explanation:
      'Remember when we pinky-promised to be best friends forever on the playground? Well, that is a legally binding document in the Court of Best Friends. You cannot escape. The statute of limitations has passed.',
  },
  {
    id: 5,
    header: 'Reason #5: Your snacks are good and I have access to them',
    explanation:
      'This is a purely transactional friendship at this point. The chips are great. The gummy bears are immaculate. Keep them coming and we will be fine.',
  },
  {
    id: 6,
    header: 'Reason #6: You make even my bad days tolerable',
    explanation:
      'When life is falling apart and I am a hot mess, you show up with snacks and zero judgment. You make me laugh when I want to cry. You are basically a licensed therapist but with worse advice and better company.',
  },
  {
    id: 7,
    header: 'Reason #7: I need someone to blame things on',
    explanation:
      '"Why is there a hole in the wall?" Not me. "Who ate the last slice of cake?" Definitely not me. Having you around is essential for my criminal empire. You are the perfect scapegoat.',
  },
  {
    id: 8,
    header: 'Reason #8: You tolerate my 47 unread texts',
    explanation:
      'I send essays when I am bored. I send memes at 3 AM. I send voice notes of me screaming. And you read ALL of them. Every. Single. One. That is a level of patience that should be studied by scientists.',
  },
  {
    id: 9,
    header: 'Reason #9: You have seen me at my worst and still stayed',
    explanation:
      'Messy hair, ugly cry, bad decisions, questionable life choices — you have witnessed it all and never ran away. Well, except that one time. But you came back. That is what counts.',
  },
  {
    id: 10,
    header: 'Reason #10: Because life without you would be boring, lonely, and just... less',
    explanation:
      'Real talk. You are not just my best friend — you are my person. My other half. My chosen family. The world is better, brighter, and infinitely more fun with you in it. I would choose you every single time.',
  },
];

interface ReasonsAccordionProps {
  // Optional: scroll target after this section
}

function AccordionItem({
  reason,
  index,
  isOpen,
  onToggle,
}: {
  reason: (typeof REASONS)[0];
  index: number;
  isOpen: boolean;
  onToggle: () => void;
}) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-50px' });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: -30 }}
      animate={isInView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.5, delay: index * 0.05 }}
      className="bg-white rounded-2xl shadow-md border-2 border-pink-100 overflow-hidden hover:border-pink-300 transition-all"
    >
      <button
        onClick={onToggle}
        className="w-full px-5 sm:px-6 py-4 sm:py-5 flex items-center justify-between text-left hover:bg-pink-50/50 transition-colors group"
      >
        <div className="flex items-center gap-3 sm:gap-4 flex-1">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-gradient-to-br from-pink-400 to-pink-500 flex items-center justify-center text-white font-bebas text-lg flex-shrink-0">
            {reason.id}
          </div>
          <h3 className="font-space font-bold text-sm sm:text-base text-gray-800 leading-snug">
            {reason.header}
          </h3>
        </div>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.3 }}
          className="flex-shrink-0 ml-3"
        >
          <ChevronDown size={20} className="text-pink-500" />
        </motion.div>
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.4, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            <div className="px-5 sm:px-6 pb-5 pt-2 border-t border-pink-100 bg-gradient-to-br from-pink-50/50 to-cream/50">
              <p className="font-space text-sm sm:text-base text-gray-700 leading-relaxed italic">
                {reason.explanation}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function ReasonsAccordion({}: ReasonsAccordionProps) {
  const [openId, setOpenId] = useState<number | null>(1); // First one open by default
  const titleRef = useRef(null);
  const isTitleInView = useInView(titleRef, { once: true });

  return (
    <section id="reasons" className="relative py-20 sm:py-28 px-4 sm:px-6 lg:px-8">
      <div className="absolute inset-0 bg-gradient-to-b from-cream via-pink-50/40 to-cream -z-10" />

      <div className="max-w-3xl mx-auto">
        <motion.div
          ref={titleRef}
          initial={{ opacity: 0, y: 30 }}
          animate={isTitleInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <span className="inline-flex items-center gap-2 px-4 py-1 bg-pink-100 text-rose-gold rounded-full text-sm font-space mb-4">
            <Gavel size={14} />
            Legal Documentation
          </span>
          <h2 className="font-bebas text-4xl sm:text-5xl md:text-6xl gradient-text tracking-wider mb-4">
            10 REASONS I LEGALLY TOLERATE YOU
          </h2>
          <p className="text-rose-gold/70 font-space text-base sm:text-lg">
            A legally binding list, filed in the Court of Best Friends. 📜
          </p>
        </motion.div>

        <div className="space-y-3 sm:space-y-4">
          {REASONS.map((reason, index) => (
            <AccordionItem
              key={reason.id}
              reason={reason}
              index={index}
              isOpen={openId === reason.id}
              onToggle={() => setOpenId(openId === reason.id ? null : reason.id)}
            />
          ))}
        </div>

        {/* Footer joke */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="mt-10 text-center"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full border-2 border-pink-200 shadow-sm">
            <FileText size={16} className="text-pink-500" />
            <span className="text-xs sm:text-sm text-gray-600 font-mono italic">
              Document signed, sealed, and notarized. Deal with it. ⚖️
            </span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
