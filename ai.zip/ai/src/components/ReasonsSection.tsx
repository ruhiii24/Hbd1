import { motion, useInView } from 'framer-motion';
import { useRef, useState } from 'react';
import { Heart, Star, Smile, Sparkles, Shield, Infinity } from 'lucide-react';

// ============================================
// CUSTOMIZE: Edit the reasons to make them personal!
// ============================================
const REASONS = [
  {
    id: 1,
    icon: Shield,
    title: 'The Ultimate Secret Keeper',
    description: 'You have held my deepest secrets and wildest dreams with a loyalty that never wavers. I trust you with my whole heart.',
    color: 'from-pink-100 to-pink-200',
    iconColor: '#B76E79',
  },
  {
    id: 2,
    icon: Smile,
    title: 'The Human Anti-Depressant',
    description: 'No matter how dark my days get, you always find a way to make me laugh until I forget what I was sad about.',
    color: 'from-lavender to-lavender-dark',
    iconColor: '#9B7CB6',
  },
  {
    id: 3,
    icon: Star,
    title: 'My Partner in Crime',
    description: 'From spontaneous adventures to the most questionable decisions, you are always down for the ride.',
    color: 'from-cream to-cream-dark',
    iconColor: '#D4AF37',
  },
  {
    id: 4,
    icon: Sparkles,
    title: 'The Smart One',
    description: 'Brilliant, creative, and wise beyond your years. You give the best advice and always know what to say.',
    color: 'from-pink-50 to-lavender',
    iconColor: '#FF91A4',
  },
  {
    id: 5,
    icon: Heart,
    title: 'The Kindest Soul',
    description: 'Your kindness radiates from everything you do. The world is a better place just by having you in it.',
    color: 'from-rose-gold-light/20 to-pink-100',
    iconColor: '#E85D75',
  },
  {
    id: 6,
    icon: Infinity,
    title: 'My Forever Person',
    description: 'Through every chapter of life, you have been my constant. You are my family, my soulmate, my forever.',
    color: 'from-gold-light/20 to-cream',
    iconColor: '#D4AF37',
  },
];

function ReasonCard({ reason, index }: { reason: typeof REASONS[0]; index: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-80px' });
  const [isHovered, setIsHovered] = useState(false);
  const Icon = reason.icon;

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 60 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.7, delay: index * 0.15 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="relative group"
    >
      <div className={`h-full p-6 sm:p-8 rounded-3xl bg-gradient-to-br ${reason.color} border border-white/50 shadow-sm card-lift overflow-hidden`}>
        <motion.div
          animate={isHovered ? { rotate: 15, scale: 1.2 } : { rotate: 0, scale: 1 }}
          transition={{ duration: 0.4 }}
          className="absolute -top-4 -right-4 opacity-10"
        >
          <Icon size={120} color={reason.iconColor} />
        </motion.div>

        <motion.div
          animate={isHovered ? { y: -5 } : { y: 0 }}
          className="w-14 h-14 rounded-2xl bg-white/80 flex items-center justify-center mb-5 shadow-sm"
        >
          <Icon size={28} color={reason.iconColor} />
        </motion.div>

        <h3 className="font-playfair text-xl sm:text-2xl font-bold text-gray-800 mb-3">
          {reason.title}
        </h3>

        <p className="font-lato text-sm sm:text-base text-gray-600 leading-relaxed">
          {reason.description}
        </p>

        <motion.div
          animate={isHovered ? { width: '100%' } : { width: '30%' }}
          transition={{ duration: 0.4 }}
          className="h-1 rounded-full mt-6"
          style={{ backgroundColor: reason.iconColor }}
        />
      </div>
    </motion.div>
  );
}

export default function ReasonsSection() {
  const titleRef = useRef(null);
  const isTitleInView = useInView(titleRef, { once: true });

  return (
    <section id="reasons" className="relative py-20 sm:py-28 px-4 sm:px-6 lg:px-8">
      <div className="absolute inset-0 bg-gradient-to-b from-cream via-pink-50/30 to-cream -z-10" />

      <div className="max-w-7xl mx-auto">
        <motion.div
          ref={titleRef}
          initial={{ opacity: 0, y: 30 }}
          animate={isTitleInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1 bg-lavender text-purple-700 rounded-full text-sm font-lato mb-4">
            💝 The Truth
          </span>
          <h2 className="font-playfair text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold gradient-text mb-4">
            Reasons Why You Are Loved
          </h2>
          <p className="text-rose-gold/60 font-lato text-base sm:text-lg max-w-2xl mx-auto">
            If I listed every reason, this page would never end. Here are the ones 
            that make my heart overflow with gratitude.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {REASONS.map((reason, index) => (
            <ReasonCard key={reason.id} reason={reason} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
