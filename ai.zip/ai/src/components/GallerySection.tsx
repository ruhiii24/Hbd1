import { useRef, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { Camera, Eye } from 'lucide-react';

// ============================================
// 🖼️ CUSTOMIZE #2: REPLACE THESE IMAGE URLs! 🖼️
// ============================================
// Mix of gorgeous photos and hilarious Snapchat-filter photos!
// Each image has a sarcastic caption.
// ============================================
const GALLERY_ITEMS = [
  {
    id: 1,
    src: 'https://placehold.co/600x750/FF10F0/FFFFFF?text=Hot+Pic',
    caption: 'See? You can take a normal photo when you try.',
    alt: 'Beautiful best friend photo',
    rotation: -4,
    isGorgeous: true,
  },
  {
    id: 2,
    src: 'https://placehold.co/600x750/FFD1DC/B76E79?text=What+Is+This',
    caption: 'I am BEGGING you to never post this.',
    alt: 'Hilarious unflattering photo',
    rotation: 3,
    isGorgeous: false,
  },
  {
    id: 3,
    src: 'https://placehold.co/600x750/39FF14/000000?text=Iconic',
    caption: 'Main character energy. As always.',
    alt: 'Best friend iconic photo',
    rotation: -2,
    isGorgeous: true,
  },
  {
    id: 4,
    src: 'https://placehold.co/600x750/FF91A4/FFFFFF?text=Delete+This',
    caption: 'Why do I still have this. Why do I keep it.',
    alt: 'Silly unflattering photo',
    rotation: 4,
    isGorgeous: false,
  },
  {
    id: 5,
    src: 'https://placehold.co/600x750/9B7CB6/FFFFFF?text=Gorgeous',
    caption: 'The face that started our friendship.',
    alt: 'Beautiful memory photo',
    rotation: -3,
    isGorgeous: true,
  },
  {
    id: 6,
    src: 'https://placehold.co/600x750/D4AF37/FFFFFF?text=OOPS',
    caption: 'The angle. The filter. The regret.',
    alt: 'Funny selfie gone wrong',
    rotation: 2,
    isGorgeous: false,
  },
  {
    id: 7,
    src: 'https://placehold.co/600x750/FF1493/FFFFFF?text=Stunner',
    caption: 'Okay fine. You win this round.',
    alt: 'Stunning photo',
    rotation: -5,
    isGorgeous: true,
  },
  {
    id: 8,
    src: 'https://placehold.co/600x750/B76E79/FFFFFF?text=Caught',
    caption: 'The paparazzi strikes again.',
    alt: 'Candid funny photo',
    rotation: 5,
    isGorgeous: false,
  },
];

function PolaroidCard({ item, index }: { item: typeof GALLERY_ITEMS[0]; index: number }) {
  const ref = useRef(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-50px' });
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  const [isShaking, setIsShaking] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateX = ((y - centerY) / centerY) * -10;
    const rotateY = ((x - centerX) / centerX) * 10;
    setRotation({ x: rotateX, y: rotateY });
  };

  const handleMouseLeave = () => {
    setRotation({ x: 0, y: 0 });
  };

  const handleClick = () => {
    setIsShaking(true);
    setTimeout(() => setIsShaking(false), 500);
  };

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 80, rotate: 0 }}
      animate={isInView ? { opacity: 1, y: 0, rotate: item.rotation } : {}}
      transition={{
        duration: 0.8,
        delay: index * 0.1,
        type: 'spring',
        damping: 12,
      }}
      className="polaroid"
      style={{ transformStyle: 'preserve-3d' }}
    >
      <motion.div
        ref={cardRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        onClick={handleClick}
        animate={
          isShaking
            ? { rotate: [0, -5, 5, -5, 5, 0], x: [0, -8, 8, -8, 8, 0] }
            : {
                rotateX: rotation.x,
                rotateY: rotation.y,
                rotateZ: 0,
              }
        }
        transition={{ duration: isShaking ? 0.4 : 0.1 }}
        className="bg-white p-3 sm:p-4 rounded-sm shadow-xl cursor-pointer shake-on-click"
        style={{ transformStyle: 'preserve-3d' }}
      >
        {/* Tape */}
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-16 h-6 bg-yellow-100/60 rotate-[-2deg] shadow-sm" />

        {/* Image */}
        <div className="aspect-[4/5] overflow-hidden bg-gradient-to-br from-pink-50 to-lavender relative">
          <img
            src={item.src}
            alt={item.alt}
            className="w-full h-full object-cover img-zoom"
            loading="lazy"
          />

          {/* "Exposing" badge for unflattering ones */}
          {!item.isGorgeous && (
            <div className="absolute top-2 right-2 bg-neon-pink text-white text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wider shadow-lg">
              EXPOSED 💀
            </div>
          )}
          {item.isGorgeous && (
            <div className="absolute top-2 right-2 bg-neon-green text-black text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wider shadow-lg">
              HOT 🔥
            </div>
          )}
        </div>

        {/* Caption */}
        <div className="pt-3 pb-2 px-2 text-center">
          <p className="font-dancing text-base sm:text-lg text-rose-gold leading-tight">
            {item.caption}
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function GallerySection() {
  const titleRef = useRef(null);
  const isTitleInView = useInView(titleRef, { once: true });

  return (
    <section id="gallery" className="relative py-20 sm:py-28 px-4 sm:px-6 lg:px-8">
      <div className="absolute inset-0 bg-gradient-to-b from-cream via-pink-50/40 to-cream -z-10" />

      <div className="max-w-7xl mx-auto">
        <motion.div
          ref={titleRef}
          initial={{ opacity: 0, y: 30 }}
          animate={isTitleInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.div
            animate={{ rotate: [0, -5, 5, 0] }}
            transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
            className="inline-block mb-4"
          >
            <span className="inline-flex items-center gap-2 px-4 py-1 bg-pink-100 text-rose-gold rounded-full text-sm font-space">
              <Camera size={14} />
              Visual Evidence
            </span>
          </motion.div>
          <h2 className="font-bebas text-4xl sm:text-5xl md:text-6xl lg:text-7xl gradient-text tracking-wider mb-4">
            A VISUAL TIMELINE OF YOUR WORST ANGLES
          </h2>
          <p className="text-rose-gold/70 font-space text-base sm:text-lg max-w-2xl mx-auto">
            <Eye className="inline mr-2" size={18} />
            Proof that I still love you despite all of this. Hover for 3D, click to shake. (You have been warned.)
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 sm:gap-10 max-w-6xl mx-auto px-4">
          {GALLERY_ITEMS.map((item, index) => (
            <PolaroidCard key={item.id} item={item} index={index} />
          ))}
        </div>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="text-center mt-12 text-xs text-rose-gold/50 italic font-space"
        >
          💡 Tip: Hover for the 3D effect. Click the cards to make them shake (like my patience with you).
        </motion.p>
      </div>
    </section>
  );
}
