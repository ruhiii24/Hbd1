import { useState, useRef } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { Send, Lock, Smile, Drama, Brain, Heart } from 'lucide-react';

// ============================================
// CUSTOMIZE: Adjust the messages for each slider!
// ============================================

const getDramaMessage = (value: number) => {
  if (value === 0) return 'Suspiciously calm today... what did you do? 👀';
  if (value < 25) return 'Mild drama. Barely a Netflix subplot.';
  if (value < 50) return 'Reality TV worthy. Still tolerable.';
  if (value < 75) return 'Calm down, Netflix series main character.';
  if (value < 100) return 'Put the phone down. BREATHE.';
  return '🚨 ALERT: Drama levels exceeding federal limits. Someone call the authorities.';
};

const getAttitudeMessage = (value: number) => {
  if (value === 0) return 'Did someone replace you with a Stepford wife?';
  if (value < 25) return "Saint mode activated. We don't trust it.";
  if (value < 50) return "Decent. I'll allow it.";
  if (value < 75) return 'Snarky queen behavior. Iconic.';
  if (value < 100) return 'Maximum sass. I fear for your enemies.';
  return '💀 You woke up and chose violence. God help us all.';
};

const getMissingMessage = (value: number) => {
  if (value === 0) return 'Wow. The audacity. The NERVE. 😤';
  if (value < 25) return 'Lies. You texted me yesterday.';
  if (value < 50) return 'Acceptable. Keep going.';
  if (value < 75) return 'Aww, you DO have a heart. 🥹';
  if (value < 100) return 'I miss you too, loser. Call me.';
  return '💖 Mutual obsession. This is healthy and not weird at all.';
};

const getIntelligenceMessage = (value: number) => {
  // Always caps at 50%!
  const cappedValue = Math.min(value, 50);
  if (cappedValue === 0) return 'Brightness level: rock with a pulse.';
  if (cappedValue < 15) return 'Have you tried Google? Just Google it.';
  if (cappedValue < 30) return "You're doing amazing sweetie 💅";
  if (cappedValue < 45) return 'Genuinely impressed. Suspicious, but impressed.';
  return "🎓 Don't get cocky. Still capped at 50% though. By law.";
};

interface SliderConfig {
  id: string;
  label: string;
  icon: typeof Drama;
  color: string;
  value: number;
  message: (v: number) => string;
  max?: number;
}

// Removed onSubmit from props so it doesn't trigger parent scrolling
export default function MetricsSection() {
  const [sliders, setSliders] = useState({
    drama: 50,
    attitude: 50,
    miss: 50,
    intelligence: 25,
  });
  
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [isShaking, setIsShaking] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true, margin: '-100px' });

  const handleSliderChange = (id: keyof typeof sliders, value: number) => {
    // Intelligence is CAPPED at 50%
    if (id === 'intelligence') {
      value = Math.min(value, 50);
    }
    setSliders({ ...sliders, [id]: value });
    
    // Once she interacts, unlock the submit button
    if (!isUnlocked) setIsUnlocked(true);
    
    // Hide the FBI message if she changes sliders after submitting
    if (isSubmitted) setIsSubmitted(false);
  };

  const handleSubmit = (e: React.MouseEvent) => {
    e.preventDefault();
    if (!isUnlocked) {
      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 500);
      return;
    }
    
    // Show the FBI message locally instead of scrolling
    setIsSubmitted(true);
  };

  const sliderConfigs: SliderConfig[] = [
    {
      id: 'drama',
      label: 'Drama Level',
      icon: Drama,
      color: 'text-pink-500',
      value: sliders.drama,
      message: getDramaMessage,
    },
    {
      id: 'attitude',
      label: 'Attitude Today',
      icon: Smile,
      color: 'text-purple-500',
      value: sliders.attitude,
      message: getAttitudeMessage,
    },
    {
      id: 'miss',
      label: 'How much you miss me right now',
      icon: Heart,
      color: 'text-rose-gold',
      value: sliders.miss,
      message: getMissingMessage,
    },
    {
      id: 'intelligence',
      label: 'Intelligence (Maxes out at 50%)',
      icon: Brain,
      color: 'text-green-500',
      value: sliders.intelligence,
      message: getIntelligenceMessage,
      max: 50,
    },
  ];

  return (
    <section
      ref={sectionRef}
      id="metrics"
      className="relative py-20 sm:py-28 px-4 sm:px-6 lg:px-8 overflow-hidden"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-cream via-lavender/30 to-cream -z-10" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full bg-purple-100/20 blur-3xl -z-10" />

      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <span className="inline-block px-4 py-1 bg-purple-100 text-purple-700 rounded-full text-sm font-space mb-4">
            📊 Official Assessment
          </span>
          <h2 className="font-bebas text-4xl sm:text-5xl md:text-6xl gradient-text tracking-wider mb-4">
            BSF GOSSIP & COMPLIMENT METER
          </h2>
          <p className="text-rose-gold/70 font-space text-base sm:text-lg">
            Calibrate yourself, bestie. The truth is in the sliders. 👇
          </p>
        </motion.div>

        {/* Sliders */}
        <div className="space-y-6 sm:space-y-8">
          {sliderConfigs.map((config, index) => {
            const Icon = config.icon;
            return (
              <motion.div
                key={config.id}
                initial={{ opacity: 0, x: -50 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white rounded-2xl p-5 sm:p-6 shadow-lg border-2 border-pink-100 hover:border-pink-300 transition-colors"
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className={`w-10 h-10 rounded-full bg-pink-50 flex items-center justify-center ${config.color}`}>
                    <Icon size={20} />
                  </div>
                  <h3 className="font-space font-bold text-base sm:text-lg text-gray-800 flex-1">
                    {config.label}
                  </h3>
                  <div className="font-bebas text-2xl text-pink-500 tracking-wider">
                    {config.value}%
                  </div>
                </div>

                <input
                  type="range"
                  min="0"
                  max={config.max || 100}
                  value={config.value}
                  onChange={(e) => handleSliderChange(config.id as keyof typeof sliders, parseInt(e.target.value))}
                  className="w-full"
                />

                <motion.p
                  key={config.value}
                  initial={{ opacity: 0, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-3 text-sm sm:text-base text-gray-600 italic font-space min-h-[24px]"
                >
                  &quot;{config.message(config.value)}&quot;
                </motion.p>
              </motion.div>
            );
          })}
        </div>

        {/* Submit Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-10 text-center"
        >
          <motion.button
            onClick={handleSubmit}
            animate={isShaking ? { x: [-10, 10, -10, 10, 0] } : {}}
            transition={{ duration: 0.4 }}
            disabled={!isUnlocked}
            className={`group relative px-8 py-4 rounded-full font-bold text-base sm:text-lg transition-all duration-300 ${
              isUnlocked
                ? 'bg-gradient-to-r from-pink-400 to-pink-500 text-white hover:shadow-xl hover:scale-105 cursor-pointer'
                : 'bg-gray-200 text-gray-400 cursor-not-allowed'
            }`}
          >
            {isUnlocked && (
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-pink-400 to-pink-500 blur-md opacity-50 group-hover:opacity-80 animate-pulse-glow" />
            )}
            <span className="relative flex items-center gap-2">
              {isUnlocked ? (
                <>
                  <Send size={18} />
                  Submit My Metrics
                </>
              ) : (
                <>
                  <Lock size={18} />
                  Submit (move the sliders first)
                </>
              )}
            </span>
          </motion.button>

          {/* Dynamic Text Under Button */}
          <div className="mt-4 min-h-[24px]">
            <AnimatePresence mode="wait">
              {!isUnlocked ? (
                <motion.p
                  key="locked"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="text-xs text-gray-500 italic"
                >
                  🔒 Submit is locked. Adjust at least one slider to unlock your destiny.
                </motion.p>
              ) : isSubmitted ? (
                <motion.p
                  key="submitted"
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-sm sm:text-base text-gray-600 italic font-space"
                >
                  &quot;Your metrics have been submitted. The FBI will review them shortly.&quot;
                </motion.p>
              ) : null}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
