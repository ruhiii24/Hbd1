import { useState, useRef } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import confetti from 'canvas-confetti';
import { X, PartyPopper, Flame } from 'lucide-react';

// ============================================
// CUSTOMIZE: Edit the wish/roast message!
// ============================================
const CAKE_CAPTION = 'Count the candles quickly before the fire hazard team arrives.';
const CAKE_BUTTON_TEXT = 'Blow candles (and wish for better style/sanity)';
const WISH_POPUP_TITLE = "You're Older Now!";
const WISH_POPUP_TEXT =
  "Yay, you're officially older. Now make a wish... preferably for a better best friend, but you're stuck with me. 💖🎂";

export default function CakeSection() {
  const [candlesBlown, setCandlesBlown] = useState(false);
  const [showWish, setShowWish] = useState(false);
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true, margin: '-100px' });

  const blowCandles = () => {
    if (candlesBlown) return;
    setCandlesBlown(true);

    const duration = 4000;
    const end = Date.now() + duration;
    const colors = ['#FF10F0', '#FF1493', '#FFD1DC', '#FF91A4', '#FFF8E7', '#D4AF37', '#39FF14'];

    const frame = () => {
      confetti({
        particleCount: 6,
        angle: 60,
        spread: 75,
        origin: { x: 0, y: 0.7 },
        colors,
        shapes: ['circle', 'square'],
        scalar: 1.4,
      });
      confetti({
        particleCount: 6,
        angle: 120,
        spread: 75,
        origin: { x: 1, y: 0.7 },
        colors,
        shapes: ['circle', 'square'],
        scalar: 1.4,
      });
      confetti({
        particleCount: 10,
        spread: 140,
        origin: { y: 0.4 },
        colors,
        shapes: ['circle', 'square'],
        scalar: 1.6,
        gravity: 0.6,
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();

    setTimeout(() => setShowWish(true), 800);
  };

  const Candle = ({ delay, x }: { delay: number; x: string }) => (
    <div 
      className="absolute bottom-0 flex flex-col items-center" 
      style={{ left: x, transform: 'translateX(-50%)' }}
    >
      <AnimatePresence>
        {!candlesBlown && (
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{
              opacity: 0,
              scale: 0,
              y: -30,
              transition: { duration: 0.4 },
            }}
            className="flame animate-flicker mb-1"
            style={{ animationDelay: `${delay}s` }}
          />
        )}
      </AnimatePresence>
      <div className="w-0.5 h-2 bg-gray-700" />
      <div className="w-3.5 h-12 bg-gradient-to-b from-pink-200 via-pink-300 to-pink-400 rounded-sm shadow-md relative overflow-hidden">
        <div className="absolute inset-x-0 top-1 h-px bg-white/40" />
        <div className="absolute inset-x-0 top-3 h-px bg-white/40" />
        <div className="absolute inset-x-0 top-5 h-px bg-white/30" />
        <div className="absolute inset-x-0 top-7 h-px bg-white/30" />
        <div className="absolute top-2 left-0 right-0 h-1 bg-pink-100/50" />
      </div>
    </div>
  );

  return (
    <section id="cake" className="relative py-20 sm:py-28 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-cream via-pink-50 to-cream -z-10" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full bg-pink-100/30 blur-3xl -z-10" />

      <div ref={sectionRef} className="max-w-4xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="mb-8"
        >
          <span className="inline-flex items-center gap-2 px-4 py-1 bg-pink-100 text-rose-gold rounded-full text-sm font-space mb-4">
            🎂 Cake Alert
          </span>
          <h2 className="font-bebas text-4xl sm:text-5xl md:text-6xl lg:text-7xl gradient-text tracking-wider mb-4">
            AGGRESSIVE CAKE
          </h2>
          <p className="text-rose-gold/70 font-space text-base sm:text-lg max-w-xl mx-auto italic">
            {CAKE_CAPTION}
          </p>
        </motion.div>

        {/* Updated Right-Side-Up Cake Structure */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="relative inline-block mt-16"
        >
          {/* Top Tier */}
          <div className="relative w-32 sm:w-40 mx-auto z-30">
            {/* Candles locked to the top tier */}
            <div className="absolute top-0 left-0 right-0 z-40">
              <Candle delay={0} x="15%" />
              <Candle delay={0.2} x="35%" />
              <Candle delay={0.4} x="50%" />
              <Candle delay={0.1} x="65%" />
              <Candle delay={0.3} x="85%" />
            </div>

            <div className="h-20 bg-gradient-to-b from-pink-100 via-pink-200 to-pink-300 rounded-t-md shadow-inner relative overflow-hidden">
              <div className="flex justify-around pt-3 px-3">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="text-xs text-gold">✦</div>
                ))}
              </div>
              <div className="absolute bottom-0 left-0 right-0 flex justify-center gap-1">
                {[...Array(7)].map((_, i) => (
                  <div key={i} className="w-5 h-5 bg-pink-200 rounded-t-full" />
                ))}
              </div>
            </div>
          </div>

          {/* Middle Tier */}
          <div className="w-48 sm:w-56 mx-auto -mt-2 relative z-20">
            <div className="h-24 bg-gradient-to-b from-cream via-cream-dark to-cream-dark/90 rounded-t-lg shadow-inner relative overflow-hidden">
              <div className="flex justify-around pt-3 px-4">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="w-3 h-3 rounded-full bg-pink-200/70" />
                ))}
              </div>
              <div className="absolute inset-x-0 top-1/2 h-px bg-gold/30" />
              <div className="flex justify-around pt-2 px-4 mt-2">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="w-2 h-2 rounded-full bg-rose-gold/30" />
                ))}
              </div>
            </div>
          </div>

          {/* Bottom Tier */}
          <div className="w-64 sm:w-72 mx-auto -mt-2 relative z-10">
            <div className="h-28 bg-gradient-to-b from-pink-200 via-pink-300 to-pink-400 rounded-t-xl shadow-inner relative overflow-hidden">
              <div className="flex justify-around pt-4 px-4">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="w-2 h-2 rounded-full bg-white/60" />
                ))}
              </div>
              <div className="flex justify-around pt-6 px-6">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="w-2 h-2 rounded-full bg-white/40" />
                ))}
              </div>
              <div className="flex justify-around pt-3 px-4">
                {[...Array(7)].map((_, i) => (
                  <div key={i} className="w-1.5 h-1.5 rounded-full bg-white/50" />
                ))}
              </div>
            </div>
          </div>

          {/* Cake Stand Plate */}
          <div className="w-72 sm:w-80 h-3 bg-gradient-to-b from-gray-300 to-gray-400 rounded-full mx-auto shadow-lg relative z-0" />
          
          {/* Cake Stand Pillar */}
          <div className="w-8 h-12 bg-gradient-to-b from-gray-300 to-gray-400 mx-auto shadow-md" />
          
          {/* Cake Stand Base */}
          <div className="w-56 h-3 bg-gradient-to-b from-gray-300 to-gray-400 rounded-full mx-auto shadow-lg" />
        </motion.div>

        {/* Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-12"
        >
          <button
            onClick={blowCandles}
            disabled={candlesBlown}
            className={`group relative px-8 py-4 rounded-full font-bold text-base sm:text-lg transition-all duration-500 ${
              candlesBlown
                ? 'bg-gray-200 text-gray-500 cursor-default'
                : 'bg-gradient-to-r from-pink-400 to-pink-500 text-white shadow-lg hover:shadow-2xl hover:scale-105'
            }`}
          >
            {!candlesBlown && (
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-pink-400 to-pink-500 blur-md opacity-50 group-hover:opacity-80 animate-pulse-glow" />
            )}
            <span className="relative flex items-center gap-2">
              {candlesBlown ? (
                <>
                  <PartyPopper size={20} />
                  Candles obliterated. Damage done.
                </>
              ) : (
                <>
                  <Flame size={20} />
                  {CAKE_BUTTON_TEXT}
                </>
              )}
            </span>
          </button>
        </motion.div>
      </div>

      {/* Wish Popup */}
      <AnimatePresence>
        {showWish && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[80] flex items-center justify-center px-4"
            onClick={() => setShowWish(false)}
          >
            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
            <motion.div
              initial={{ scale: 0.5, opacity: 0, y: 50 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.5, opacity: 0, y: 50 }}
              transition={{ type: 'spring', damping: 20 }}
              className="relative bg-gradient-to-br from-pink-50 via-cream to-lavender p-8 sm:p-12 rounded-3xl shadow-2xl max-w-md w-full text-center border-2 border-pink-200"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setShowWish(false)}
                className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/50 flex items-center justify-center hover:bg-white transition-colors"
                aria-label="Close"
              >
                <X size={16} className="text-rose-gold" />
              </button>

              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: 'spring' }}
                className="text-6xl mb-4"
              >
                ✨🎂✨
              </motion.div>

              <h3 className="font-bebas text-3xl sm:text-4xl gradient-text tracking-wide mb-4">
                {WISH_POPUP_TITLE}
              </h3>

              <p className="font-space text-base sm:text-lg text-rose-gold leading-relaxed">
                {WISH_POPUP_TEXT}
              </p>

              <button
                onClick={() => setShowWish(false)}
                className="mt-6 px-6 py-2 bg-gradient-to-r from-pink-400 to-pink-500 text-white rounded-full font-bold text-sm hover:shadow-lg transition-all"
              >
                Close (you're welcome)
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
