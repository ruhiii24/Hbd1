import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, ShieldCheck, AlertCircle, Lock } from 'lucide-react';

// ============================================
// CUSTOMIZE: Put YOUR name here!
// This is the food promise check
// ============================================
const MY_NAME = 'ruhiii'; // <-- Change this to YOUR name!

// Optional: Change the food to something specific
const FOOD_PROMISE = 'ice cream'; // <-- Could be "boba", "tacos", "coffee", etc.

interface CaptchaSectionProps {
  onVerified: () => void;
}

export default function CaptchaSection({ onVerified }: CaptchaSectionProps) {
  const [agreed, setAgreed] = useState(false);
  const [isShaking, setIsShaking] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleCheckboxChange = () => {
    const newValue = !agreed;
    setAgreed(newValue);
    if (!newValue) {
      // If she unchecks, shake the verify button
      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 500);
    }
  };

  const handleVerify = () => {
    if (!agreed) {
      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 500);
      return;
    }
    setShowSuccess(true);
    setTimeout(() => {
      onVerified();
    }, 1500);
  };

  return (
    <AnimatePresence>
      {!showSuccess && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, y: -100 }}
          className="fixed inset-0 z-[90] flex items-center justify-center px-4 overflow-y-auto py-8"
        >
          {/* Backdrop */}
          <div className="absolute inset-0 bg-gradient-to-br from-pink-50 via-cream to-lavender -z-10" />
          <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" />

          {/* Decorative blobs */}
          <div className="absolute top-10 left-10 w-72 h-72 rounded-full bg-pink-200/40 blur-3xl -z-10" />
          <div className="absolute bottom-10 right-10 w-96 h-96 rounded-full bg-lavender/50 blur-3xl -z-10" />

          {/* CAPTCHA Card */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', damping: 20 }}
            className="relative max-w-md w-full"
          >
            <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-2xl border-2 border-pink-200">
              {/* Header */}
              <div className="flex items-center gap-3 mb-6 pb-4 border-b border-pink-100">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-pink-400 to-pink-500 flex items-center justify-center">
                  <Shield size={24} className="text-white" />
                </div>
                <div className="flex-1">
                  <h2 className="font-bebas text-xl text-gray-800 tracking-wide">SECURITY CHECK</h2>
                  <p className="text-xs text-gray-500">BSF Verification System™</p>
                </div>
                <div className="text-xs text-gray-400 font-mono">v.2.0.25</div>
              </div>

              {/* Title */}
              <h3 className="font-space text-base sm:text-lg font-semibold text-gray-800 mb-6 leading-relaxed">
                Prove you are actually my BSF and not some random annoying person trying to steal my birthday wishes.
              </h3>

              {/* Checkbox */}
              <label className="flex items-start gap-3 p-4 bg-pink-50 rounded-xl cursor-pointer hover:bg-pink-100 transition-colors border-2 border-pink-200 hover:border-pink-400 mb-6">
                <input
                  type="checkbox"
                  checked={agreed}
                  onChange={handleCheckboxChange}
                  className="custom-checkbox mt-0.5"
                />
                <span className="font-space text-sm text-gray-700 leading-relaxed">
                  I solemnly swear that I will buy <span className="font-bold text-pink-500">{MY_NAME}</span>{' '}
                  <span className="font-bold">{FOOD_PROMISE}</span> next time we hang out.
                  <span className="block text-xs text-gray-500 mt-1 italic">
                    (This is non-negotiable and legally binding in the court of best friends.)
                  </span>
                </span>
              </label>

              {/* Verify button */}
              <motion.button
                onClick={handleVerify}
                disabled={!agreed}
                animate={isShaking ? { x: [-10, 10, -10, 10, 0] } : {}}
                transition={{ duration: 0.4 }}
                className={`w-full py-4 rounded-xl font-bold text-sm sm:text-base transition-all duration-300 ${
                  agreed
                    ? 'bg-gradient-to-r from-pink-400 to-pink-500 text-white hover:shadow-xl hover:scale-[1.02] cursor-pointer'
                    : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                }`}
              >
                <span className="flex items-center justify-center gap-2">
                  {agreed ? (
                    <>
                      <ShieldCheck size={18} />
                      VERIFY MY BSF STATUS
                    </>
                  ) : (
                    <>
                      <Lock size={18} />
                      VERIFY (you must agree first)
                    </>
                  )}
                </span>
              </motion.button>

              {/* Warning */}
              {!agreed && (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="mt-4 text-xs text-center text-gray-500 italic flex items-center justify-center gap-1"
                >
                  <AlertCircle size={12} />
                  <span>You must check the box to continue. I see you trying to cheat.</span>
                </motion.p>
              )}

              {/* Footer joke */}
              <p className="mt-6 pt-4 border-t border-pink-100 text-center text-xs text-gray-400 font-mono">
                reCAPTCHA-Friendship-Edition™ • Secure since 2021
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
