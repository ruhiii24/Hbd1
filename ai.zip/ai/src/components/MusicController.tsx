import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Pause, Play, Volume2 } from 'lucide-react';

// ============================================
// 🎵 CUSTOMIZE #1: PASTE YOUR MUSIC LINK HERE! 🎵
// ============================================
// Replace the URL below with your audio file.
// For best results, use a direct .mp3 URL.
//
// Examples:
//   - Direct audio: 'https://example.com/song.mp3'
//   - SoundHelix demo: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'
//
// For YouTube/Spotify, see comments below the component.
// ============================================
const MUSIC_URL = 'https://mathematical-beige-zfi7w83e.edgeone.dev/Gigi%20Perez%20-%20Sailor%20Song%20[Official%20Audio](MP3_160K).mp3';

// For YouTube embed, replace MUSIC_URL with:
// 'https://www.youtube.com/embed/VIDEO_ID?autoplay=0'
// And change the <audio> tag to <iframe> in the JSX below.
// ============================================

const MUSIC_TAG = 'Brought to you by my superior music taste. 🎵';

export default function MusicController() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [showHint, setShowHint] = useState(true);
  const [volume, setVolume] = useState(0.5);
  const [showExpanded, setShowExpanded] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => setShowHint(false), 5000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().catch(() => setIsPlaying(false));
      setIsPlaying(true);
    }
    setShowHint(false);
  };

  return (
    <>
      {/* Hidden audio element */}
      <audio ref={audioRef} src={MUSIC_URL} loop preload="auto" />

      {/* Floating music widget */}
      <motion.div
        initial={{ opacity: 0, scale: 0 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 1, type: 'spring', damping: 15 }}
        className="fixed bottom-6 left-6 z-50"
        onMouseEnter={() => setShowExpanded(true)}
        onMouseLeave={() => setShowExpanded(false)}
      >
        <div className="relative">
          {/* Sarcastic tag */}
          <AnimatePresence>
            {showHint && (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="absolute left-full ml-3 top-1/2 -translate-y-1/2 whitespace-nowrap max-w-[200px]"
              >
                <div className="bg-white/90 backdrop-blur-sm px-3 py-2 rounded-lg shadow-lg border-2 border-pink-200">
                  <p className="text-[10px] sm:text-xs text-rose-gold font-space font-semibold">
                    {MUSIC_TAG}
                  </p>
                </div>
                <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1 w-2 h-2 bg-white/90 rotate-45 border-l border-b border-pink-200" />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Music control panel */}
          <motion.div
            animate={{ width: showExpanded || isPlaying ? 'auto' : '56px' }}
            className="glass rounded-full shadow-xl flex items-center overflow-hidden border-2 border-pink-200/50"
          >
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={togglePlay}
              className={`relative w-14 h-14 flex items-center justify-center rounded-full flex-shrink-0 ${
                isPlaying ? 'animate-pulse-glow' : ''
              }`}
              aria-label={isPlaying ? 'Pause music' : 'Play music'}
            >
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-pink-400 to-pink-500 opacity-90" />
              <div className="relative z-10 text-white">
                {isPlaying ? <Pause size={20} /> : <Play size={20} className="ml-0.5" />}
              </div>

              {isPlaying && (
                <>
                  <motion.div
                    animate={{ y: [-5, -25, -5], opacity: [0, 1, 0], x: [0, 5, 0] }}
                    transition={{ duration: 2, repeat: Infinity, delay: 0 }}
                    className="absolute -top-1 left-2 text-white text-sm"
                  >
                    ♪
                  </motion.div>
                  <motion.div
                    animate={{ y: [-5, -30, -5], opacity: [0, 1, 0], x: [0, -5, 0] }}
                    transition={{ duration: 2.5, repeat: Infinity, delay: 0.5 }}
                    className="absolute -top-1 right-2 text-white text-sm"
                  >
                    ♫
                  </motion.div>
                </>
              )}
            </motion.button>

            <AnimatePresence>
              {showExpanded && (
                <motion.div
                  initial={{ width: 0, opacity: 0 }}
                  animate={{ width: 'auto', opacity: 1 }}
                  exit={{ width: 0, opacity: 0 }}
                  className="flex items-center gap-2 pr-4 overflow-hidden"
                >
                  <Volume2 size={14} className="text-pink-500 flex-shrink-0" />
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={volume}
                    onChange={(e) => setVolume(parseFloat(e.target.value))}
                    className="w-20 h-1 accent-pink-500 cursor-pointer"
                    aria-label="Volume"
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </motion.div>
    </>
  );
}
