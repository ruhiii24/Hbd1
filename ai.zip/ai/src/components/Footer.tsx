import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { Heart } from 'lucide-react';

// ============================================
// CUSTOMIZE: Change the footer text!
// ============================================
const FOOTER_TEXT = 'Made with minimal effort and maximum love by your favorite human.';
const FOOTER_SUBTEXT = 'Happy Birthday! 🎉 (Now go venmo me for hosting this site.)';

export default function Footer() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <footer className="relative py-16 px-4 sm:px-6 lg:px-8">
      <div className="absolute inset-0 bg-gradient-to-t from-pink-100/50 via-cream to-cream -z-10" />

      <div ref={ref} className="max-w-4xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <div className="w-24 h-px bg-gradient-to-r from-transparent via-pink-500 to-transparent mx-auto mb-8" />

          <p className="font-space text-base sm:text-lg text-rose-gold/80 font-medium">
            {FOOTER_TEXT}
          </p>

          <p className="mt-3 font-dancing text-xl sm:text-2xl text-rose-gold">
            {FOOTER_SUBTEXT}
          </p>

          <p className="mt-6 font-space text-sm text-rose-gold/40">
            © {new Date().getFullYear()} • Site powered by chaos and friendship
          </p>

          <div className="flex justify-center gap-3 mt-6">
            {[...Array(5)].map((_, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0 }}
                animate={isInView ? { opacity: 0.4, scale: 1 } : {}}
                transition={{ delay: 0.3 + i * 0.1, type: 'spring' }}
              >
                <Heart
                  size={10 + i * 2}
                  className="text-pink-500"
                  fill="#FF10F0"
                />
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </footer>
  );
}
