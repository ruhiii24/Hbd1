import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Crown, Skull, Sparkles } from 'lucide-react';

// ============================================
// CUSTOMIZE: Edit gate text if you want!
// ============================================
const GATE_TITLE = '⚠️ WARNING ⚠️';
const GATE_WARNING = 'You are entering the Birthdays-of-People-Who-Are-Getting-Old Zone.';
const GATE_QUESTION = 'Are you mentally prepared?';
const GATE_YES_BTN = 'Yes, let me see my greatness';
const GATE_NO_BTN = "No, I'm too weak";

interface EntryGateProps {
  onEnter: () => void;
}

export default function EntryGate({ onEnter }: EntryGateProps) {
  const [isExiting, setIsExiting] = useState(false);
  const [noBtnPos, setNoBtnPos] = useState({ x: 0, y: 0 });
  const [noBtnText, setNoBtnText] = useState(GATE_NO_BTN);
  const containerRef = useRef<HTMLDivElement>(null);

  const moveNoButton = () => {
    if (!containerRef.current) return;
    const containerRect = containerRef.current.getBoundingClientRect();
    const maxX = containerRect.width / 2 - 80;
    const maxY = 100;
    const newX = (Math.random() - 0.5) * 2 * maxX;
    const newY = (Math.random() - 0.5) * 2 * maxY;
    setNoBtnPos({ x: newX, y: newY });

    // Change text after multiple attempts
    const attempts = ['Too slow!', 'Nope!', 'Try again!', 'Nice try 😂', 'Catch me!', "Can't touch this"];
    setNoBtnText(attempts[Math.floor(Math.random() * attempts.length)]);
  };

  const handleYes = () => {
    setIsExiting(true);
    setTimeout(onEnter, 700);
  };

  return (
    <AnimatePresence>
      {!isExiting && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{
            opacity: 0,
            scale: 1.5,
            filter: 'blur(20px)',
            transition: { duration: 0.7 },
          }}
          className="fixed inset-0 z-[100] flex items-center justify-center px-4 overflow-hidden"
        >
          {/* Animated background */}
          <div className="absolute inset-0 bg-gradient-to-br from-pink-50 via-cream to-lavender animate-gradient-shift -z-10" />

          {/* Floating elements */}
          <div className="absolute inset-0 overflow-hidden -z-5 pointer-events-none">
            {[...Array(12)].map((_, i) => (
              <motion.div
                key={i}
                initial={{ y: '110vh', x: `${Math.random() * 100}vw`, opacity: 0 }}
                animate={{ y: '-10vh', opacity: [0, 1, 1, 0] }}
                transition={{
                  duration: 8 + Math.random() * 4,
                  repeat: Infinity,
                  delay: Math.random() * 5,
                  ease: 'linear',
                }}
                className="absolute"
                style={{ left: `${Math.random() * 100}%` }}
              >
                {i % 3 === 0 ? (
                  <span className="text-pink-300 text-2xl">💖</span>
                ) : i % 3 === 1 ? (
                  <Sparkles size={20} className="text-pink-400" />
                ) : (
                  <span className="text-rose-gold text-xl">✨</span>
                )}
              </motion.div>
            ))}
          </div>

          {/* Glow background blobs */}
          <div className="absolute top-10 left-10 w-72 h-72 rounded-full bg-pink-200/40 blur-3xl -z-10" />
          <div className="absolute bottom-10 right-10 w-96 h-96 rounded-full bg-lavender/50 blur-3xl -z-10" />

          {/* Main content card */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
            className="relative max-w-xl w-full"
          >
            <div className="glass rounded-3xl p-8 sm:p-12 text-center shadow-2xl border-2 border-pink-200/50">
              {/* Warning emoji */}
              <motion.div
                animate={{ rotate: [0, -10, 10, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
                className="text-6xl sm:text-7xl mb-4 inline-block"
              >
                👵
              </motion.div>

              {/* Title */}
              <h1 className="font-bebas text-4xl sm:text-5xl md:text-6xl neon-text mb-4 tracking-wide">
                {GATE_TITLE}
              </h1>

              {/* Warning text */}
              <p className="font-space text-base sm:text-lg text-rose-gold font-semibold mb-3">
                {GATE_WARNING}
              </p>

              <p className="font-dancing text-2xl sm:text-3xl text-rose-gold mb-8">
                {GATE_QUESTION}
              </p>

              {/* Buttons */}
              <div
                ref={containerRef}
                className="relative flex flex-col sm:flex-row gap-4 items-center justify-center min-h-[140px] sm:min-h-[80px]"
              >
                {/* YES BUTTON */}
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleYes}
                  className="group relative inline-flex items-center gap-2"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-pink-400 to-pink-500 rounded-full blur-lg opacity-70 group-hover:opacity-100 transition-opacity animate-pulse-glow" />
                  <div className="relative px-6 sm:px-8 py-4 bg-gradient-to-r from-pink-400 to-pink-500 text-white font-bold text-sm sm:text-base rounded-full shadow-xl">
                    <span className="flex items-center gap-2">
                      <Crown size={18} />
                      {GATE_YES_BTN}
                    </span>
                  </div>
                </motion.button>

                {/* NO BUTTON - runs away! */}
                <motion.button
                  animate={{ x: noBtnPos.x, y: noBtnPos.y }}
                  transition={{ type: 'spring', damping: 15, stiffness: 300 }}
                  onMouseEnter={moveNoButton}
                  onClick={moveNoButton}
                  onTouchStart={moveNoButton}
                  className="runaway-btn group relative inline-flex items-center gap-2"
                >
                  <div className="px-6 sm:px-8 py-4 bg-gray-300 text-gray-600 font-semibold text-sm sm:text-base rounded-full shadow-md">
                    <span className="flex items-center gap-2">
                      <Skull size={18} />
                      {noBtnText}
                    </span>
                  </div>
                </motion.button>
              </div>

              {/* Hint */}
              <p className="mt-6 font-space text-xs text-rose-gold/60 italic">
                💡 Pro tip: just click the first button 👀
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
