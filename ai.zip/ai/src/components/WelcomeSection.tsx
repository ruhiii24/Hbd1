import { motion } from 'framer-motion';
import { ChevronDown, Sparkles } from 'lucide-react';

export default function WelcomeSection() {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden px-4 py-12">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-pink-50 via-cream to-lavender -z-10" />
      <div className="absolute top-20 left-10 w-64 h-64 rounded-full bg-pink-100/40 blur-3xl -z-10" />
      <div className="absolute bottom-20 right-10 w-80 h-80 rounded-full bg-lavender/40 blur-3xl -z-10" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full bg-cream-dark/30 blur-3xl -z-10" />

      {/* Main content */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, ease: 'easeOut' }}
        className="text-center z-10 max-w-4xl mx-auto"
      >
        {/* Small greeting */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="inline-block mb-4"
        >
          <span className="inline-flex items-center gap-2 px-4 py-1 bg-pink-100 text-rose-gold rounded-full text-xs sm:text-sm font-space">
            <Sparkles size={14} />
            Welcome, ancient one
          </span>
        </motion.div>

        {/* Main heading */}
        <motion.h1
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5, duration: 0.8, type: 'spring' }}
          className="font-bebas text-5xl sm:text-6xl md:text-8xl lg:text-9xl gradient-text leading-tight mb-2 tracking-wide"
        >
          HAPPY BIRTHDAY
        </motion.h1>

        <motion.h2
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.7, duration: 0.8, type: 'spring' }}
          className="font-dancing text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-rose-gold mb-8"
        >
          to my favorite autistic creature!
        </motion.h2>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9 }}
          className="text-rose-gold/70 font-space text-sm sm:text-base md:text-lg max-w-xl mx-auto mb-10 px-4"
        >
          Get ready for an unhinged celebration filled with roasts, confetti, sarcasm, 
          and just enough genuine love to make you cry. You earned it, old lady. 💖
        </motion.p>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.1 }}
          className="flex flex-col sm:flex-row gap-4 items-center justify-center"
        >
          <a
            href="#cake"
            className="inline-flex items-center gap-2 px-6 sm:px-8 py-3 sm:py-4 bg-gradient-to-r from-pink-400 to-pink-500 text-white font-bold rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 animate-pulse-glow"
          >
            🎂 Start the Chaos
          </a>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.3 }}
          className="mt-12 flex flex-wrap justify-center gap-6 sm:gap-10"
        >
          <div className="text-center">
            <div className="font-bebas text-3xl sm:text-4xl gradient-text">9</div>
            <div className="text-xs text-rose-gold/60 font-space uppercase tracking-wider">Sections</div>
          </div>
          <div className="text-center">
            <div className="font-bebas text-3xl sm:text-4xl gradient-text">∞</div>
            <div className="text-xs text-rose-gold/60 font-space uppercase tracking-wider">Roasts</div>
          </div>
          <div className="text-center">
            <div className="font-bebas text-3xl sm:text-4xl gradient-text">100%</div>
            <div className="text-xs text-rose-gold/60 font-space uppercase tracking-wider">Love</div>
          </div>
          <div className="text-center">
            <div className="font-bebas text-3xl sm:text-4xl gradient-text">0%</div>
            <div className="text-xs text-rose-gold/60 font-space uppercase tracking-wider">Filter</div>
          </div>
        </motion.div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <a href="#cake" className="flex flex-col items-center text-rose-gold/60 hover:text-rose-gold transition-colors">
          <span className="text-xs uppercase tracking-widest mb-2 font-space">Scroll if you dare</span>
          <ChevronDown size={24} className="animate-bounce" />
        </a>
      </motion.div>
    </section>
  );
}
