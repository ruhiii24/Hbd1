import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart } from 'lucide-react';

export default function ScrollToTop() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.scrollY > 500) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.button
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0 }}
          transition={{ type: 'spring', damping: 15 }}
          onClick={scrollToTop}
          className="fixed bottom-6 right-6 z-40 group"
          aria-label="Scroll to top"
        >
          <div className="absolute inset-0 rounded-full bg-pink-400 blur-md opacity-50 group-hover:opacity-80 transition-opacity animate-pulse-glow" />
          <div className="relative w-12 h-12 rounded-full bg-gradient-to-br from-pink-400 to-pink-500 text-white shadow-lg flex items-center justify-center transition-all duration-300 group-hover:scale-110">
            <Heart size={20} fill="white" />
          </div>
        </motion.button>
      )}
    </AnimatePresence>
  );
}
