import { useState } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { useRef } from 'react';
import { Mail, Heart, X } from 'lucide-react';

// ============================================
// 💌 CUSTOMIZE #3: EDIT YOUR PERSONAL LETTER HERE! 💌
// Structure: ROAST → HEARTFELT → JOKE
// ============================================
const LETTER_DATA = {
  greeting: 'Hey You,',

  // PART 1: THE ROAST (starts with humor)
  roast:
    "Listen. I have spent a LOT of time thinking about what to write here, and I want you to know that I am mostly doing this because I have to. It is contractual. We talked about this. (Also because your therapist said I should \"express my feelings.\" Ugh.) Honestly, you are the most annoying person I have ever met — in the BEST possible way. You snore louder than a freight train. You steal fries off my plate like a raccoon. You send me TikToks at 4 AM like a psychopath. You have the memory of a goldfish and the stubbornness of a mule.",

  // PART 2: THE HEARTFELT PART (the real feelings)
  heartfelt: [
    "But here is the thing I will probably never say out loud enough: you are the best thing that has ever happened to me.",

    "You walked into my life one day and just... stayed. Through every awkward phase, every bad haircut, every questionable life choice, every 3 AM crying session, every victory I needed someone to celebrate with — you have been there. Every single time. Without fail.",

    "You make me laugh until my stomach hurts. You make me feel seen when I am at my lowest. You make the world feel less scary and more like an adventure. You are the sister I got to choose, the family that feels like home, the person I would literally call in the middle of the night if the world was ending.",

    "I do not say this enough, but thank you. For choosing me. For staying. For being unapologetically YOU. For letting me be unapologetically me. For being the kind of friend that people write songs about but never quite capture how magical it actually feels.",

    "On your birthday, I just want you to know: you matter. To me. To so many people. You are loved beyond what words can hold, and I am so lucky — SO lucky — that I get to be one of the people who gets to love you.",
  ],

  // PART 3: THE FINAL JOKE (lightens it back up)
  joke:
    "Okay, that was way too many feelings. I am going to go eat a whole pizza and pretend I never wrote this. You did NOT see this. We are even. Now go have the best birthday ever because you are stuck with me forever whether you like it or not. 💖",

  closing: 'Forever your emotional prisoner,',
  signature: 'Your BSF (obviously)',
};

export default function LetterSection() {
  const [isEnvelopeOpen, setIsEnvelopeOpen] = useState(false);
  const [showLetterModal, setShowLetterModal] = useState(false);
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true, margin: '-100px' });

  const handleEnvelopeClick = () => {
    if (isEnvelopeOpen) {
      setShowLetterModal(true);
      return;
    }
    setIsEnvelopeOpen(true);
    setTimeout(() => setShowLetterModal(true), 1200);
  };

  return (
    <section id="letter" className="relative py-20 sm:py-28 px-4 sm:px-6 lg:px-8">
      <div className="absolute inset-0 bg-gradient-to-b from-cream via-pink-50/60 to-cream -z-10" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-pink-100/30 blur-3xl -z-10" />

      <div ref={sectionRef} className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <span className="inline-flex items-center gap-2 px-4 py-1 bg-lavender text-purple-700 rounded-full text-sm font-space mb-4">
            <Mail size={14} />
            Final Transmission
          </span>
          <h2 className="font-bebas text-4xl sm:text-5xl md:text-6xl gradient-text tracking-wider mb-4">
            THE EMOTIONAL PAYLOAD
          </h2>
          <p className="text-rose-gold/70 font-space text-base sm:text-lg">
            Brace yourself. Feelings incoming. 💌
          </p>
        </motion.div>

        {/* Envelope */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex justify-center"
        >
          <button
            onClick={handleEnvelopeClick}
            disabled={isEnvelopeOpen}
            className="group relative cursor-pointer focus:outline-none"
            aria-label="Open letter"
          >
            {/* Wax seal */}
            {!isEnvelopeOpen && (
              <motion.div
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20"
              >
                <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-br from-pink-400 to-pink-500 shadow-xl flex items-center justify-center">
                  <Heart size={28} className="text-white animate-heart-beat" fill="white" />
                </div>
                <div className="absolute inset-0 rounded-full bg-pink-400 blur-md opacity-50" />
              </motion.div>
            )}

            <div className="envelope-body relative">
              <div className={`envelope-flap ${isEnvelopeOpen ? 'open' : ''}`} />

              <div className={`envelope-letter ${isEnvelopeOpen ? 'peek' : ''}`}>
                <div className="text-center px-4">
                  <p className="text-sm sm:text-base italic">
                    {isEnvelopeOpen ? 'Tap to read...' : 'Open if you dare 💌'}
                  </p>
                </div>
              </div>

              {!isEnvelopeOpen && (
                <>
                  <div className="absolute -top-4 -left-4 text-gold animate-sparkle">✨</div>
                  <div className="absolute -top-4 -right-4 text-pink-300 animate-sparkle" style={{ animationDelay: '0.5s' }}>✨</div>
                  <div className="absolute -bottom-4 -left-4 text-rose-gold animate-sparkle" style={{ animationDelay: '1s' }}>✨</div>
                  <div className="absolute -bottom-4 -right-4 text-gold animate-sparkle" style={{ animationDelay: '1.5s' }}>✨</div>
                </>
              )}
            </div>

            {!isEnvelopeOpen && (
              <motion.p
                animate={{ y: [0, -5, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="mt-8 text-center font-dancing text-xl sm:text-2xl text-rose-gold"
              >
                Tap to open (you know you want to)
              </motion.p>
            )}
          </button>
        </motion.div>
      </div>

      {/* Letter Modal */}
      <AnimatePresence>
        {showLetterModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[80] flex items-center justify-center p-4 overflow-y-auto"
            onClick={() => setShowLetterModal(false)}
          >
            <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />

            <motion.div
              initial={{ scale: 0.5, opacity: 0, y: 100 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.5, opacity: 0, y: 100 }}
              transition={{ type: 'spring', damping: 20 }}
              className="relative my-8 max-w-2xl w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="parchment rounded-2xl p-8 sm:p-12 md:p-16 relative overflow-hidden">
                {/* Watermark */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-[0.04] pointer-events-none">
                  <Heart size={300} fill="#B76E79" />
                </div>

                <button
                  onClick={() => setShowLetterModal(false)}
                  className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/70 hover:bg-white flex items-center justify-center transition-colors z-10"
                  aria-label="Close letter"
                >
                  <X size={18} className="text-rose-gold" />
                </button>

                <div className="absolute -top-3 -left-3 w-12 h-12 border-t-2 border-l-2 border-gold/30 rounded-tl-lg" />
                <div className="absolute -top-3 -right-3 w-12 h-12 border-t-2 border-r-2 border-gold/30 rounded-tr-lg" />
                <div className="absolute -bottom-3 -left-3 w-12 h-12 border-b-2 border-l-2 border-gold/30 rounded-bl-lg" />
                <div className="absolute -bottom-3 -right-3 w-12 h-12 border-b-2 border-r-2 border-gold/30 rounded-br-lg" />

                {/* Greeting */}
                <p className="font-dancing text-2xl sm:text-3xl text-rose-gold mb-6">
                  {LETTER_DATA.greeting}
                </p>

                {/* THE ROAST */}
                <p className="font-space text-sm sm:text-base text-gray-700 leading-relaxed mb-6 italic border-l-4 border-pink-300 pl-4">
                  {LETTER_DATA.roast}
                </p>

                {/* THE HEARTFELT */}
                <div className="space-y-4 mb-6">
                  {LETTER_DATA.heartfelt.map((paragraph, index) => (
                    <p
                      key={index}
                      className="font-dancing text-base sm:text-lg text-gray-800 leading-relaxed"
                    >
                      {paragraph}
                    </p>
                  ))}
                </div>

                {/* THE JOKE */}
                <p className="font-space text-sm sm:text-base text-gray-700 leading-relaxed mb-6 italic border-l-4 border-pink-300 pl-4">
                  {LETTER_DATA.joke}
                </p>

                {/* Closing */}
                <div className="mt-8 text-right">
                  <p className="font-space text-gray-600 mb-2 italic text-sm">{LETTER_DATA.closing}</p>
                  <p className="font-dancing text-2xl sm:text-3xl text-rose-gold">
                    {LETTER_DATA.signature}
                  </p>
                </div>

                <div className="mt-6 h-px bg-gradient-to-r from-transparent via-gold/40 to-transparent" />

                <div className="flex justify-center gap-2 mt-5">
                  <Heart size={16} className="text-pink-300 animate-heart-beat" style={{ animationDelay: '0s' }} fill="#FFB6C1" />
                  <Heart size={20} className="text-pink-400 animate-heart-beat" style={{ animationDelay: '0.2s' }} fill="#FF10F0" />
                  <Heart size={16} className="text-pink-300 animate-heart-beat" style={{ animationDelay: '0.4s' }} fill="#FFB6C1" />
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
