import { useEffect, useState } from 'react';
import { Heart, Star, Sparkles } from 'lucide-react';

interface FloatingItem {
  id: number;
  x: number;
  delay: number;
  duration: number;
  size: number;
  type: 'heart' | 'star' | 'sparkle';
  color: string;
}

export default function FloatingElements() {
  const [items, setItems] = useState<FloatingItem[]>([]);

  useEffect(() => {
    const colors = ['#FF10F0', '#FF1493', '#FFB6C1', '#39FF14', '#D4AF37'];
    const newItems: FloatingItem[] = [];

    for (let i = 0; i < 12; i++) {
      newItems.push({
        id: i,
        x: Math.random() * 100,
        delay: Math.random() * 15,
        duration: 12 + Math.random() * 15,
        size: 12 + Math.random() * 18,
        type: ['heart', 'star', 'sparkle'][Math.floor(Math.random() * 3)] as 'heart' | 'star' | 'sparkle',
        color: colors[Math.floor(Math.random() * colors.length)],
      });
    }
    setItems(newItems);
  }, []);

  const renderIcon = (item: FloatingItem) => {
    const props = { size: item.size, color: item.color, style: { opacity: 0.35 } };
    switch (item.type) {
      case 'heart': return <Heart {...props} fill={item.color} />;
      case 'star': return <Star {...props} fill={item.color} />;
      case 'sparkle': return <Sparkles {...props} />;
    }
  };

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-[1]">
      {items.map((item) => (
        <div
          key={item.id}
          className="absolute animate-drift"
          style={{
            left: `${item.x}%`,
            animationDelay: `${item.delay}s`,
            animationDuration: `${item.duration}s`,
          }}
        >
          {renderIcon(item)}
        </div>
      ))}
    </div>
  );
}
